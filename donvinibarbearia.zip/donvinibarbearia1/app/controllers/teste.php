<?php

namespace app\controllers;
require_once  dirname( __DIR__ , 1).'/config.php';

use app\core\CodeGenerator;

$codeG = new CodeGenerator();

echo $codeG->run(50);